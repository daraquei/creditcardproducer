package com.example.daraquei.kafka.creditcardproducer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreditcardproducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
