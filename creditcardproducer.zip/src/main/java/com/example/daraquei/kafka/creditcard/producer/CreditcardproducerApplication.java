package com.example.daraquei.kafka.creditcard.producer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreditcardproducerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreditcardproducerApplication.class, args);
	}

}
